import React from 'react'
import Elementorsection from '../Components/Homepage/Elementorsection'
import { NavLink } from 'react-router-dom'
import Homeheader from '../Components/Homepage/Homeheader'
import CategorProduct from '../Components/Homepage/CategorProduct'
import Todaydeal from '../Components/Homepage/MidComponent/Todaydeal'
import Productca from '../Components/Homepage/Productca'

import {products} from '../assets/assests'
import {audioandvideo} from '../assets/assests'
import {HomeAPpliance} from '../assets/assests'
import {Airconditioner} from '../assets/assests'
import {KitchenAppliance} from '../assets/assests'

function Home() {
  return (
    <>
   
    <Homeheader/>
    <div className='mb-[10vh] '>
     <Elementorsection  /> 
     </div>
<CategorProduct/>
    <Todaydeal/>
    <Productca array={products} title="Today's best deal" />
    <Productca array={audioandvideo} title="Audio and Video" />
    <Productca array={HomeAPpliance} title="Home Appliances" />
    <Productca array={Airconditioner} title="Air Conditioner" />
    <Productca array={KitchenAppliance} title="Kitchen Appliances" />
    
    </>
  )
}

export default Home