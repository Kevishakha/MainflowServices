import img1 from './categoryimg/ace.jpg'
import img2 from './categoryimg/gadget.jpg'
import img3 from './categoryimg/Homeappliance.jpg'
import img4 from './categoryimg/kitchenapplian.jpg'
import img5 from './categoryimg/pcs.jpg'
import img6 from './categoryimg/refrigrator.jpg'
import img7 from './categoryimg/smarthome.jpg'
import img8 from './categoryimg/tv.jpg'

import ima1 from './audio/audio1.jpg'
import ima2 from './audio/audio2.jpg'
import ima3 from './audio/audio3.jpg'
import ima4 from './audio/audio4.jpg'

import image1 from './todaydeal/groomer.jpg'
import image2 from './todaydeal/sound.jpg'
import image3 from './todaydeal/voice.jpg'
import image4 from './todaydeal/tab.jpg'
import image5 from './todaydeal/ivoilet.jpg'
import image6 from './todaydeal/ivoilet.jpg'
import image7 from './todaydeal/laptop.jpg'
import image8 from './todaydeal/laptop.jpg'

import imh from './homeapplian/multigroomer.jpg'
import imh1 from './homeapplian/blackma.jpg'
import imh2 from './homeapplian/washing.jpg'
import imh3 from './homeapplian/bmg.jpg'

import imac from './airconditioner/electronic-store-product-image-10.jpg'
import imac1 from './airconditioner/electronic-store-product-image-11.jpg'
import imac2 from './airconditioner/electronic-store-product-image-16.jpg'
import imac3 from './airconditioner/electronic-store-product-image-9.jpg'

import imk from './Kitchenappliance/electronic-store-product-image-3.jpg'
import imk1 from './Kitchenappliance/electronic-store-product-image-4.jpg'
import imk2 from './Kitchenappliance/electronic-store-product-image-6.jpg'
import imk3 from './Kitchenappliance/electronic-store-product-image-8.jpg'


export const categories = [
    { id: 1, image: img1, name: "Air Conditioner" },
    { id: 2, image: img2, name: "Gadget" },
    { id: 3, image: img3, name: "Home Appliance" },
    { id: 4, image: img4, name: "Kitchen Appliance" },
    { id: 5, image: img5, name: "Pc and Laptop" },
    { id: 6, image: img6, name: "Refrigrator" },
    { id: 7, image: img7, name: "Smarthome" },
    { id: 8, image: img8, name: "Telivision" },
  ];
  export const KitchenAppliance = [
    {
      id: 1,
      name:"0.9 Cubic Feet Capacity 900 Watts Kitchen Essentials for the Countertop Stainless Steel",
      image: imk,
      category: "Electronics",
      beforePrice: "$120",
      dealPrice: "$80",
    },
    {
      id: 2,
      name:"Microwave Oven with Smart Sensor Easy Clean Interior ECO Mode 1.2 Cu Ft Stainless Steel",
      image: imk1,
      category: "Wearable",
      beforePrice: "$150",
      dealPrice: "$100",
    },
    {
      id: 3,
      name:"Double Door Mini Fridge with Freezer for Office or Dorm with Adjustable Remove Glass Shelves",
      image: imk2,
      category: "Accessories",
      beforePrice: "$60",
      dealPrice: "$40",
    },
    {
      id: 4,
      name:"36″ Side-by-Side Refrigerator and Freezer with 25 Cubic Ft. Total Capacity, Black",
       image: imk3,
      category: "Audio",
      beforePrice: "$90",
      dealPrice: "$60",
    },]


  export const Airconditioner = [
    {
      id: 1,
      name:"Air Conditioner 5000 BTU, Efficient Cooling for Smaller Areas Like Bedrooms and Guest Rooms",
      image: imac,
      category: "Electronics",
      beforePrice: "$120",
      dealPrice: "$80",
    },
    {
      id: 2,
      name:"Dual Hose Portable Air Conditioner, Dehumidifier, Fan with Activated Carbon Filter in Platinum",
      image: imac1,
      category: "Wearable",
      beforePrice: "$150",
      dealPrice: "$100",
    },
    {
      id: 3,
      name:"Star 9,500 BTU 115V Dual Inverter Window Air Conditioner with Wi-Fi Control",
      image: imac2,
      category: "Accessories",
      beforePrice: "$60",
      dealPrice: "$40",
    },
    {
      id: 4,
      name:"BTU 115V Window-Mounted Air Conditioner with Remote Control White",
       image: imac3,
      category: "Audio",
      beforePrice: "$90",
      dealPrice: "$60",
    },]
  export const HomeAPpliance = [
    {
      id: 1,
      name: "Multigroomer All-in-One Trimmer Series 5000, 23 Piece Mens Grooming Kit",
      image: imh,
      category: "Electronics",
      beforePrice: "$120",
      dealPrice: "$80",
    },
    {
      id: 2,
      name: "Compact Pulsator Washer for Clothes, .9 Cubic ft. Tub, White, BPAB10WH",
      image: imh1,
      category: "Wearable",
      beforePrice: "$150",
      dealPrice: "$100",
    },
    {
      id: 3,
      name: "Full-Automatic Compact Washer with Wheels, 1.6 cu. ft, 11 lbs capacity with 6 Wash Programs Washer",
      image: imh2,
      category: "Accessories",
      beforePrice: "$60",
      dealPrice: "$40",
    },
    {
      id: 4,
      name: "Small Space Heat Pump Dryer with Sensor Dry, 12 Preset Machine Cycles, 40 Minute Express Drying",
      image: imh3,
      category: "Audio",
      beforePrice: "$90",
      dealPrice: "$60",
    },]
  
  export const audioandvideo = [
    {
      id: 1,
      name: "Max SR Home Theater Surround Sound Bar HDMI, Optical Cables, Wireless Subwoofer & Two Speakers",
      image: ima1,
      category: "Electronics",
      beforePrice: "$120",
      dealPrice: "$80",
    },
    {
      id: 2,
      name: "V-Series 5.1 Home Theater Sound Bar with Dolby Audio, Bluetooth, Wireless Subwoofer, Voice Assistant Compatible",
      image: ima2,
      category: "Wearable",
      beforePrice: "$150",
      dealPrice: "$100",
    },
    {
      id: 3,
      name: "OLED C1 Series 55” 4k Smart TV (3840 x 2160), 120Hz Refresh Rate, AI-Powered 4K, Dolby Cinema, WiSA Ready, Gaming Mode",
      image: ima3,
      category: "Accessories",
      beforePrice: "$60",
      dealPrice: "$40",
    },
    {
      id: 4,
      name: "X80J 55 Inch TV: 4K Ultra HD LED Smart Google TV with Dolby Vision HDR",
      image: ima4,
      category: "Audio",
      beforePrice: "$90",
      dealPrice: "$60",
    },]

  export const products = [
    {
      id: 1,
      name: "Multigroomer All-in-One Trimmer Series 5000, 23 Piece Mens Grooming Kit",
      category: "",
      image: image1,
      beforePrice: "$200",
      dealPrice: "$150",
    },
    {
      id: 2,
      name: "Smart Speaker with Alexa Voice Control Built-in Compact Size with Incredible Sound for Any Room",
      category: "Category B",
      image: image2,
      beforePrice: "$250",
      dealPrice: "$180",
    },
    {
        id: 3,
        name: "Home Speaker 500: Smart Bluetooth Speaker with Alexa Voice Control Built-In, White",
        category: "Category B",
        image: image3,
        beforePrice: "$250",
        dealPrice: "$180",
      },
      {
        id: 4,
        name: "Note 10 Pro 128GB 6GB RAM Factory Unlocked (GSM ONLY) International Model",
        category: "Category B",
        image:image4 ,
        beforePrice: "$250",
        dealPrice: "$180",
      },
      {
        id: 5,
        name: "5G Unlocked Smartphone,12GB RAM+256GB Storage120Hz Fluid Display Hasselblad Quad Camera 65W Ultra Fast Charge 50W Wireless Charge",
        category: "Category B",
        image: image5,
        beforePrice: "$250",
        dealPrice: "$180",
      },
      {
        id: 6,
        name: "5G Factory Unlocked Android Cell Phone 128GB Pro-Grade Camera 30X Space Zoom Night Mode, Space Grey",
        category: "Category B",
        image: image6,
        beforePrice: "$250",
        dealPrice: "$180",
      },
      {
        id: 7,
        name: "13 Ultrabook Gaming Laptop: Intel Core i7-1165G7 4 Core, NVIDIA GeForce GTX 1650 Ti Max-Q, 13.3″ 1080p 120Hz, 16GB RAM, 512GB SSD, CNC Aluminum, Chroma RGB, Thunderbolt 4",
        category: "Category B",
        image:image7 ,
        beforePrice: "$250",
        dealPrice: "$180",
      },
      {
        id: 8,
        name: "15.6″ FHD Display Laptop – Intel i7 – Intel HD Graphics 6000 , Webcam, WiFi, Bluetooth, HDMI, Windows 11,Grey",
        category: "Category B",
        image: image8 ,
        beforePrice: "$250",
        dealPrice: "$180",
      },
    // Add up to 8 products
  ];