import React, { useState } from "react";
import { FaEnvelope } from "react-icons/fa";
import { FaRegEnvelopeOpen } from "react-icons/fa";

import "./foooter.css";
import {
  FaFacebookF,
  FaTwitter,
  FaInstagram,
  FaLinkedinIn,
  FaYoutube,
} from "react-icons/fa";

const Foooter = () => {

  return (
    <>
    <div className="advice-section w-[100%] flex flex-col items-center ">
      {/* Top Section */}
      <div className="top-section  h-[20vh] relative w-[80%] border-t-inherit flex flex-col justify-center border-gray-300 ">
        {/* Left Column */}
        <div className="contact-info h-full  ">
          <div className="contact-item">
            <a href="#expert-advice" className="contact-link">
              Expert Advice
            </a>
            <p>+1 234 567 890</p>
          </div>
          <div className="contact-item">
            <a href="#customer-service" className="contact-link">
              Customer Service
            </a>
            <p>+1 234 567 891</p>
          </div>
          <div className="contact-item">
            <h3>Have Any Questions?</h3>
            <p>+1 234 567 892</p>
          </div>
        </div>
       
        {/* Right Column */}
       
        
          <div className="image-container  absolute right-0 top-[-10vh] ">
          <img loading="lazy" decoding="async" width="300" height="200" src="https://websitedemos.net/electronic-store-04/wp-content/uploads/sites/1055/2022/03/electronic-store-support-team.png"
              alt="Expert Advice"
            className="advice-image"
            
          />
          

        </div>
      </div>

      {/* Bottom Section */}
      <div className="bottom-section w-[85%] h-[25vh] p-[5vh] flex justify-center  ">
        <div className="newsletter-icon flex h-[15vh] w-[10vw] justify-center items-center  gap-3 mr-[5vw] ">
          <div className=" h-full flex items-center ">
          <FaRegEnvelopeOpen size={50} />
          </div>
          <div className=" h-full text-[1.25rem] font-bold ">
          <h3>Subscribe to our Newsletter</h3>
          </div>
        </div>
        <div className="newsletter-info  h-[13vh] min-w-[25vw] mr-[5vw]  flex items-center">
          
          <p>Sign up for the latest news and exclusive offers.</p>
        </div>
        <div className="newsletter-form  h-full w-full p-[25px]  ">
          <input
            type="text"
            placeholder="Enter your email address"
            className="newsletter-input h-full"
          />
          <button className="subscribe-button h-full">Subscribe</button>
        </div>
      </div>
    </div>
   
      <footer className="">
     
      {/* Main Footer Section */}
      <div className="footer-content">
        {/* Company Info */}
        <div className="footer-section company-info">
          <div className="logo">YourLogo</div>
          <p>
            We provide the best products for your needs. Our goal is to ensure
            quality, affordability, and exceptional customer service.
          </p>
          {/* Social Media Links */}
         <div className="icons">
            Got Questions? Call Us at +914520262
         </div>
          <div className="icons social-media ">
            <div className="icon"><FaFacebookF /></div>
            <div className="icon"><FaTwitter /></div>
            <div className="icon"><FaInstagram /></div>
            <div className="icon"><FaLinkedinIn /></div>
            <div className="icon"><FaYoutube /></div>
          </div>
        </div>
        

        

        {/* Useful Links */}
        <div className="footer-section useful-links">
          <h3>Useful Links</h3>
          <ul>
            <li>Shop</li>
            <li>About Us</li>
            <li>Blog</li>
            <li>FAQs</li>
            <li>Contact Us</li>
          </ul>
        </div>

        {/* Customer Services */}
        <div className="footer-section customer-service">
          <h3>Customer Service</h3>
          <ul>
            <li>Shipping Info</li>
            <li>Returns</li>
            <li>Track Order</li>
            <li>Support</li>
            <li>Privacy Policy</li>
          </ul>
        </div>

        {/* My Account */}
        <div className="footer-section my-account">
          <h3>My Account</h3>
          <ul>
            <li>Login</li>
            <li>Register</li>
            <li>My Orders</li>
            <li>Wishlist</li>
            <li>Manage Account</li>
          </ul>
        </div>
      </div>

      {/* Footer Bottom Section */}
      <div className="footer-bottom  ">
        <div className="left">
          <p>© Copyright 2019. All rights reserved.</p>
        </div>
        <div className="right">
          <div className="partner-logos flex">
            <img src="/images/logo1.png" alt="Company Logo" />
            <img src="/images/logo2.png" alt="Company Logo" />
            <img src="/images/logo3.png" alt="Company Logo" />
            <img src="/images/logo4.png" alt="Company Logo" />
            <img src="/images/logo5.png" alt="Company Logo" />
            <img src="/images/logo6.png" alt="Company Logo" />
          </div>
        </div>
      </div>
    </footer>
    </>
  );
};

export default Foooter;