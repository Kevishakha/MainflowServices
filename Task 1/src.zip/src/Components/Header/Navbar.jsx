import React, { useState } from "react";
import './navbar.css'
import { FaSearch, FaUserAlt, FaHeart, FaShoppingCart, FaBars, FaLightbulb } from "react-icons/fa";
import { NavLink } from "react-router-dom";

import { FaChevronDown } from "react-icons/fa";

const Navbar = () => {
  const [showCategories, setShowCategories] = useState(false);

  return (
    <nav>
      {/* Top Navbar */}
      <div className="top-nav ">
        <div className="logo">YourLogo</div>
        <div className="search-bar">
          <input type="text" placeholder="Search product" />
          <FaSearch className="search-icon" />
        </div>
        <div className="top-icons flex gap-[2vw] ">
            <FaUserAlt title="Account" />
          <FaHeart title="Favorites" />
          <FaShoppingCart title="Cart" />
        </div>
      </div>

      {/* Bottom Navbar */}
      <div className="bottom-nav">
        <div className="menu-icon" onClick={() => setShowCategories(!showCategories)}>
          <FaBars />
          <span>Browse Categories</span>
        </div>
        <div className="nav-links">
      <NavLink to="/">Home<FaChevronDown /></NavLink>
      <div className="dropdown">
        <NavLink to="/">
          Pages <FaChevronDown />
        </NavLink>
        <ul className="dropdown-content">
          <li>
            <NavLink to="/">Login</NavLink>
          </li>
          <li>
            <NavLink to="/">Contact</NavLink>
          </li>
          <li>
            <NavLink to="/">About</NavLink>
          </li>
          <li>
            <NavLink to="/">Product</NavLink>
          </li>
        </ul>
      </div>
      <NavLink to="/">
        Blog <FaChevronDown />
      </NavLink>
      <NavLink to="/">
        Shop <FaChevronDown />
      </NavLink>
      <NavLink to="/">
        Element <FaChevronDown />
      </NavLink>
    </div>
        <div className="offer">
          <FaLightbulb />
          <p>Up to 30% clearance</p>
        </div>
      </div>

      {/* Categories Dropdown */}
      {showCategories && (
        <div className="categories-dropdown">
          <ul>
            <li>Electronics</li>
            <li>Fashion</li>
            <li>Home Appliances</li>
            <li>Books</li>
            <li>More...</li>
          </ul>
        </div>
      )}
    </nav>
  );
};

export default Navbar;