import React from 'react'
import bgimg from '../../../assets/middeal/electronic-store-promotional-banner-1.jpg'
import bgimg2 from '../../../assets/middeal/electronic-store-promotional-banner-2.jpg'

function Todaydeal() {
  return (
    <>
    <div className='w-[100vw] p-[10vh] flex justify-center gap-[10vh]  '>
       
        <div className='h-[20vh] w-[40%] '>
          <img src={bgimg2}/>
        </div>
        <div className='h-[20vh] w-[40%]'>
        <img src={bgimg}/>
        </div>
    </div>
    </>
  )
}

export default Todaydeal