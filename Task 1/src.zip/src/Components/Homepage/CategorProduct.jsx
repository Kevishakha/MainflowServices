import React from 'react'
import {categories} from '../../assets/assests'

import './category.css'

function CategorProduct() {
  return (
    <>


  
    <div className="category-container">
      {categories.map((category) => (
        <div className="category-item" key={category.id}>
          <div className='h-[30vh]  '>
          <img src={category.image} alt={category.name} className="category-image" />
          </div>
          <div className="category-name">{category.name}</div>
        </div>
      ))}
    </div>
  

    
    </>
  )
}

export default CategorProduct