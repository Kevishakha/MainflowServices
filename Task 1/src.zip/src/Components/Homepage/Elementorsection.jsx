import React from 'react'
import { MdOutlineLocalShipping } from "react-icons/md";
import { MdOutlineEventAvailable } from "react-icons/md";
import { GiReturnArrow } from "react-icons/gi";
import { MdOutlinePayment } from "react-icons/md";
import './home.css'

function Elementorsection() {
  return (
    <>
    
    <div className='m-auto elementor-section '>
      <div className='grid grid-cols-4 elementor-inner-section ' >
        <div className='grid-cols-1 flex elementor-column-section border-none'>
         <div className='elementor-icon-section'>
          <i><MdOutlineLocalShipping/></i>    
         </div>
         <div className='elementor-about-section'>
          <span>Free shipping</span>
          <p>When you spend more than 1000 rs.</p>
         </div>
        </div>
        <div className='grid-cols-1 flex elementor-column-section'>
         <div className='elementor-icon-section'>
          <i><MdOutlineEventAvailable/></i>    
         </div>
         <div className='elementor-about-section'>
          <span> We are available 24/7</span>
          <p>Need help? contact us anytime</p>
         </div>
        </div>
        <div className='grid-cols-1 flex elementor-column-section '>
         <div className='elementor-icon-section'>
          <i><GiReturnArrow/></i>    
         </div>
         <div className='elementor-about-section'>
          <span>Satisfied or return</span>
          <p>Easy 30-day return policy</p>
         </div>
        </div>
        <div className='grid-cols-1 flex elementor-column-section ecsl '>
         <div className='elementor-icon-section'>
          <i><MdOutlinePayment/></i>    
         </div>
         <div className='elementor-about-section'>
          <span>100% secure payments</span>
          <p>Visa, Mastercard, Stripe, PayPal</p>
         </div>
        </div>

      </div>

    </div>
    </>
  )
}

export default Elementorsection