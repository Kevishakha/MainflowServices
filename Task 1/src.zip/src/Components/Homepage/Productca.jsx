import React from 'react'

import './productslist.css'
function Productca({array, title}) {
  return (
    <>
    <div className="mains-container ">
     <div className="main-container">
     <div className="heading">
        <p className="heading-title">{title}
        <a href="#" className="see-more ml-[1vw] ">
          See More
        </a>
        </p>
      </div> 
      <div className="inner-container">
        
        {array.map((product) => (
          <div className="product-item" key={product.id}>
            <img
              src={product.image}
              alt={product.name}
              className="product-image"
            />
            <div className="product-name">{product.name}</div>
            <div className="product-prices">
              <span className="before-price">{product.beforePrice}</span>
              <span className="deal-price">{product.dealPrice}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
    </div>
    </>
  )
}

export default Productca