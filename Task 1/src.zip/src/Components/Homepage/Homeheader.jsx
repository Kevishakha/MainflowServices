import React from 'react'

function Homeheader() {
  return (
   <>
   <div className='h-[100vh] bg-red-500 bg-[] homediv relative flex justify-center items-center '>
    {/* <img src="https://websitedemos.net/electronic-store-04/wp-co…ites/1055/2022/03/electronic-store-hero-image.jpg" alt='img'/>
    */}
    <div className='w-[80vw] h-[85vh] flex justify-end bg-transparent m-auto p-[5vh]'>
        <div className=' bg-white p-[5vh] w-[27vw] flex flex-col gap-[5vh] '>
        <div className="logo">YourLogo</div>
         <div>
          <h1 className='text-4xl font-bold leading-tight '>
          The best <br/> home entertainment system is here
          </h1>
         </div>
         <p>
          We are the best home entertainment system in the world. 
         </p>
         <div><a className='text-blue-500 font-bold '>Shop Now</a></div>
        </div>
      </div>
    </div>
   </>
  )
}

export default Homeheader